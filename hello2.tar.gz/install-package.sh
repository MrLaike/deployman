
init () {
	echo "###Install tar..."
	sudo apt-get update -y && sudo apt-get install tar
}


